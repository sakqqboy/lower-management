<div class="kt-generator-default-index">
    <div class="row">
        <div class="col-md-6">
            <div class="thumbnail text-center">
                <h1>Model Generator</h1>
                <p>
                    Generate all master models and extend models
                </p>
                <a href="<?=Yii::$app->homeUrl?>kt-generator/model" class="btn btn-primary btn-block">Go!!</a>
            </div>
        </div>
        <div class="col-md-6">
            <div class="thumbnail text-center">
                <h1>CRUD Generator</h1>
                <p>
                    Generate all CRUD
                </p>
                <a href="<?=Yii::$app->homeUrl?>kt-generator/crud" class="btn btn-success btn-block">Go!!</a>
            </div>
        </div>
    </div>
</div>
